package com.example.vocascreen

import android.app.*
import android.content.Context
import android.content.pm.ServiceInfo
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.util.Locale

class CaptureService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var resultView: TextView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val main = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val words by lazy { loadWords() }
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("projectionData", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("projectionData")
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
            val metrics = resources.displayMetrics
            reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
            display = projection?.createVirtualDisplay("VocaScreen", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, main)
            showBubble()
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "voca_capture"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channel, "화면 단어 찾기", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, channel).setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("화면 단어 찾기 실행 중").setContentText("떠 있는 버튼을 눌러 현재 화면을 분석하세요")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(41, n)
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "단어\n찾기"
            textSize = 13f
            setTextColor(0xffffffff.toInt())
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xff2457a6.toInt())
            setOnClickListener { scanScreen() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 240 }
        wm.addView(bubble, p)
    }

    private fun scanScreen() {
        if (busy) return
        busy = true
        bubble?.alpha = 0.55f
        main.postDelayed({
            val image = reader?.acquireLatestImage()
            if (image == null) { busy = false; bubble?.alpha = 1f; showResult("화면 캡처에 실패했습니다. 다시 눌러 주세요."); return@postDelayed }
            val input = InputImage.fromMediaImage(image, 0)
            recognizer.process(input).addOnSuccessListener { result ->
                val found = Regex("[A-Za-z][A-Za-z'-]{1,}").findAll(result.text)
                    .map { it.value.lowercase(Locale.ROOT) }.toSet()
                val matches = words.filter { it.first.lowercase(Locale.ROOT) in found }
                val message = if (matches.isEmpty()) "단어장 일치 항목 없음\n\n화면에서 인식한 단어: ${found.take(12).joinToString(", ").ifBlank { "없음" }}"
                    else matches.joinToString("\n\n") { "${it.first}  (${it.third})\n${it.second}" }
                showResult(message)
            }.addOnFailureListener { showResult("글자 인식에 실패했습니다.") }
                .addOnCompleteListener { image.close(); busy = false; bubble?.alpha = 1f }
        }, 180)
    }

    private fun showResult(message: String) {
        main.post {
            try { resultView?.let { wm.removeView(it) } } catch (_: Exception) {}
            resultView = TextView(this).apply {
                text = message + "\n\n(닫으려면 이 창을 누르세요)"
                textSize = 15f
                setTextColor(0xff111111.toInt())
                setPadding(22, 20, 22, 20)
                setBackgroundColor(0xfff5f5f5.toInt())
                setOnClickListener { try { wm.removeView(this) } catch (_: Exception) {}; resultView = null }
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val p = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * .88).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.CENTER
            wm.addView(resultView, p)
        }
    }

    private fun loadWords(): List<Triple<String, String, String>> {
        val json = JSONArray(assets.open("words.json").bufferedReader().use { it.readText() })
        return (0 until json.length()).map { i ->
            val o = json.getJSONObject(i); Triple(o.getString("en"), o.getString("ko"), o.getString("day"))
        }
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { resultView?.let { wm.removeView(it) } } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop(); recognizer.close()
        super.onDestroy()
    }
}
