# 화면 단어 찾기 (Android)

## 기능
- 다른 앱 위에 떠 있는 파란 버튼 표시
- 버튼을 누르면 현재 화면을 캡처하고 ML Kit OCR로 영단어 추출
- 내장된 VOCA EXPRESS 누적 단어장과 대조해 영어 단어·뜻·Day 표시
- OCR과 단어 대조는 기기 내부에서 처리

## 빌드
1. Android Studio 최신 버전 설치
2. 이 폴더를 Android Studio에서 열기
3. Gradle Sync 완료
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. `app/build/outputs/apk/debug/app-debug.apk` 설치

## 최초 실행
1. 앱 실행 후 `권한 설정 및 시작` 선택
2. 다른 앱 위에 표시 권한 허용
3. 화면 캡처 권한 허용
4. 화면 오른쪽 위에 뜬 `단어 찾기` 버튼을 누르면 검색

## 제한
- Android의 화면 캡처 보호 정책이 적용된 앱(일부 금융·DRM 앱 등)은 분석할 수 없음
- OCR 특성상 작은 글씨, 기울어진 글씨, 배경과 대비가 낮은 글씨는 놓칠 수 있음
- 화면 공유/녹화가 시작되므로 캡처 권한 안내를 확인하고 사용
- 현재 이 작업 환경에는 Android SDK/Gradle 빌드 도구가 없어 APK 바이너리를 직접 컴파일하지 못함. Android Studio에서 프로젝트를 열어 APK를 생성해야 함.
